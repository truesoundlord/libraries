#! /bin/bash
echo "Deleting backup files..."
rm *~
echo "...done !"

