#!/bin/bash

export libfolder=/exemples/librairies

FOLDER=`zenity --file-selection --directory --title="[CSSM] ]Sélectionnez un dossier où installer les librairies... [CSSM]"`

case $? in
         0) #zenity --info --text="Installation des liens symboliques dans $FOLDER";
         	echo "Installation des liens symboliques dans $FOLDER";
						ln -fs $libfolder/cssm_wide/cssm_wide.h $FOLDER/. ;
						if ! test -e $libfolder/cssm_wide/cssm_wide.o;
						then
							echo "La librairie cssm_wide n'est pas compilée...";
							cd $libfolder/cssm_wide;
							make;
							echo "...compilation done";
						else
							echo "création du lien symbolique vers cssm_wide...";
						fi		
						ln -fs $libfolder/cssm_wide/cssm_wide.o $FOLDER/.;
						ln -fs $libfolder/linkedlist/*.h $FOLDER/. ;
						if ! test -e $libfolder/linkedlist/linkedlist.o;
						then
							echo "La librairie linkedlist n'est pas compilée...";
							cd $libfolder/linkedlist;
							make;
							echo "...compilation done";
						else
							echo "création du lien symbolique vers linkedlist...";
						fi
						ln -fs $libfolder/linkedlist/*.o $FOLDER/. ;
						ln -fs $libfolder/cssm_debug/cssmdebugtool.h $FOLDER/.;
						if ! test -e $libfolder/cssm_debug/cssmdebugtool.o;
						then
							echo "La librairie cssm_debugtool n'est pas compilée...";
							cd $libfolder/cssm_debug;
							make;
							echo "...compilation done";
						else
							echo "création du lien symbolique vers cssm_debugtool...";
						fi
						ln -fs $libfolder/cssm_debug/cssmdebugtool.o $FOLDER/.; 
						#zenity --info --text="Installation terminée";;
						echo "Installation terminée";;
         1) echo "Pas de dossier sélectionné.";;
        -1) echo "Une erreur inattendue est survenue (huhuhu !)";;
esac
